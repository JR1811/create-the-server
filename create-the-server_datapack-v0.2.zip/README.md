<img src="https://github.com/JR1811/create-the-server/assets/36027822/c771c3ca-93ad-4eb4-9867-733d7af90914"  width="700">

# Datapack for Create the Server

This datapack was created by members of the ["Create the Server"](https://youtu.be/9iKEQBZtjH0) project.

Builders:

- BoneCrusherx11
- Ender Haven
- ShiroJR1811

Datapack creation:

- ShiroJR1811

Check the [Wiki](https://github.com/JR1811/create-the-server/wiki) for more technical information.

## Structures

- Deepslate Mineshaft (dsms)

# How to install

Install this Datapack like any other datapack. Either choose it in the settings when creating a new world or add it to the Datapack folder of an existing world. Structures generate naturally at deepslate level but you can place them manually using the `/place structure` and `/place template` to either generate the whole structure or choose one single structure module.

# Help

If the issue hasn't been listed in the known [Issues](https://github.com/JR1811/create-the-server/issues) you may post the problem there or inform ShiroJR on Discord.
